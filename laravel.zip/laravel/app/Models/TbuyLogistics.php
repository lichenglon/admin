<?php
namespace App\Models;


class TbuyLogistics extends Base {
	protected $table = 'tbuy_logistics';
	
}