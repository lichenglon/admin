<?php
namespace App\Models;


class TbuyPayType extends Base {
	protected $table = 'tbuy_pay_type';
	
	
}