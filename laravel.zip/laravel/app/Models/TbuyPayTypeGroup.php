<?php
namespace App\Models;


class TbuyPayTypeGroup extends Base {
	protected $table = 'tbuy_pay_type_group';
	
	
}