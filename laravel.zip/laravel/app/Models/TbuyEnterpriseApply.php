<?php
namespace App\Models;


class TbuyEnterpriseApply extends Base {
	protected $table = 'tbuy_enterprise_apply';
	
}