<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Menu extends Base
{
    //菜单表
//    protected $table = 'menus';
}
