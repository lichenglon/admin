<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Nation extends Base
{
	protected $table = 'nation';//国家表
}
