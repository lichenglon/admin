<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Landlord_message extends Base
{
	protected $table = 'landlord_message';//房东信息表
}