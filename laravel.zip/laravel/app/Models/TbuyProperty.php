<?php
namespace App\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class TbuyProperty extends Base {
    protected $table = 'tbuy_property';
    
}