<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Province extends Base
{
	protected $table = 'province';//省份表
}