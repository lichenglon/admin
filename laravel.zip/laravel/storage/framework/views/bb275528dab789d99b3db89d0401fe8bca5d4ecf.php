<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="box">
        <div class="box-body">
            <form action="<?php echo e(url('nation/add/state')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <label>国家中文名称：</label> <input type="text" name="chinese_n_name" value=""><br>
                <label>国家英文名称：</label> <input type="text" name="english_n_name" value=""><br>
                <label>国家英文缩写：</label> <input type="text" name="abbreviation" value="">
                <input type="submit" value="添加">
            </form>

            <div class="alert"></div>

            <form action="<?php echo e(url('nation/add/province')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <label>所属国家：</label>
                <select name="p_nation_ID" id="" >
                    <?php $__currentLoopData = $nationArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->n_ID); ?>"><?php echo e($value->chinese_n_name); ?>&nbsp;&nbsp;&nbsp;<?php echo e($value->english_n_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <label>省份中文名称：</label> <input type="text" name="chinese_p_name" value=""><br>
                <label>省份英文名称：</label> <input type="text" name="english_p_name" value="">
                <input type="submit" value="添加">
            </form>

            <div class="alert"></div>

            <form action="<?php echo e(url('nation/add/city')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <label>所属省份：</label>
                <select name="c_province_ID" id="">
                    <?php $__currentLoopData = $provinceArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->p_ID); ?>"><?php echo e($val->chinese_p_name); ?>&nbsp;&nbsp;&nbsp;<?php echo e($val->english_p_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <label>市区中文名称：</label> <input type="text" name="chinese_c_name" value=""><br>
                <label>市区英文名称：</label> <input type="text" name="english_c_name" value="">
                <input type="submit" value="添加">
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>