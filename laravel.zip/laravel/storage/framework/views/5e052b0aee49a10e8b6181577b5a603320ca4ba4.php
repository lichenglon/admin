﻿

<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('house/css/H-ui.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="box">
		<div class="box-body">


			<div class="Hui-article">
				<article class="cl pd-20">

					<div class="cl pd-5 bg-1 bk-gray mt-20">

						<span class="select-box inline">
							<form action="<?php echo e(url('house/findType')); ?>" method="post">
								<select name="type" class="select" id="findType">
									<option value="0">全部分类</option>
									<?php $__currentLoopData = $typeObject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($value->name); ?>"><?php echo e($value->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</form>
						</span>
						当前页面检索
						<input type="text" name="" id="searching" placeholder="Please enter the content you want to search" style="width:350px" class="input-text">
						日期范围：
						<input type="text" id="rise" class="input-text" style="width:120px;">
						-
						<input type="text" id="duration" class="input-text" style="width:120px;">

						<span class="r">共有数据：<strong><?php echo e($houseCount); ?></strong> 条</span>
					</div>
					<div class="mt-20">
						<table class="table table-border table-bordered table-bg table-hover table-sort">
							<thead>
							<tr class="text-c" id="theader">
								<th width="">ID</th>
								<th width="">房源编号</th>
								<th width="">房源结构</th>
								<th width="">房源价格</th>
								<th width="">房源大小</th>
								<th width="">房屋设备</th>
								<th width="">房源位置</th>
								<th width="">租期时长</th>
								<th width="">状态</th>
								<th width="">操作</th>
							</tr>
							</thead>
							<tbody>
							<?php $__currentLoopData = $houseObj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="text-c">
									<td><?php echo e($val->msgid); ?></td>
									<td class="text-l"><a href="<?php echo e(url('house/houseLister/detail',['id'=>$val->msgid])); ?>"><u style="cursor:pointer" class="text-primary" title="查看"><?php echo e($val->serial_number); ?></u></a></td>
									<td><?php echo e($val->house_structure); ?></td>
									<td><?php echo e($val->house_price); ?></td>
									<td><span><?php echo e($val->house_size); ?></span> /平方</td>
									<td><?php $equipment = explode(',',$val->house_facility); foreach ($equipment as $value){ echo $value.'&nbsp;&nbsp;&nbsp;'; }?></td>
									<td class="text-l"><u style="cursor:pointer" class="text-primary" title="查看"><?php echo e($val->house_location); ?></u></td>
									<td><?php echo e($val->house_rise); ?><b style="font-size:15px;">~</b><?php echo e($val->house_duration); ?></td>
									<td class="td-status"><span class="label label-success radius"><?php echo e($val->house_status); ?></span></td>
									<td class="f-14 td-manage">
										<a style="text-decoration:none" class="ml-5" href="<?php echo e(url('house/houseLister/detail',['id'=>$val->msgid])); ?>" title="详细信息">详细信息</a>
									</td>
							    </tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</tbody>
						</table>
					</div>
				</article>
			</div>
			<!-- 分页 -->
			<?php if(!empty($houseObj)): ?>
				<div class="page_list">
					<?php echo e($houseObj->appends(Request::input())->links()); ?>

				</div>
			<?php endif; ?>

		</div>
	</div>


	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('js'); ?>
		<script>
			//当前页面检索
			$(function(){
				$("#searching").keyup(function(){
					var txt=$("#searching").val();
					if($.trim(txt)!=""){
						$("table tr:not('#theader')").hide().filter(":contains('"+txt+"')").show();
					}else{
						$("table tr:not('#theader')").show();
					}
				});
			})
			//分类搜索表单提交
			$("select#findType").change(function(){
				console.log('11');
			})
		</script>
		<script>
			//常规用法 日期
			laydate.render({
				elem: '#rise'
			});
			laydate.render({
				elem: '#duration'
			});
		</script>
	<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>