<?php $__env->startSection('content'); ?>


    <!-- Font Awesome -->
    
    <!-- bootstrap wysihtml5 - text editor -->
    

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <!--<script src="dist/js/html5shiv.min.js"></script>-->
    
    <![endif]-->
    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "https://hm.baidu.com/hm.js?4155d5c32d834c8bb2c4b5fe64542f66";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>








<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<!-- jQuery UI 1.11.4 -->


    <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>