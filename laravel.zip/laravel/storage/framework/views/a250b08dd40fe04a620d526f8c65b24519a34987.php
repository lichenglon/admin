

<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php if(isset($__user_info__)): ?> <?php echo e($__user_info__['name']); ?> <?php endif; ?></p>
                <!-- Status -->
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <!-- search form (Optional) -->
        
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">主导航</li>


            <?php $__currentLoopData = $__menu_lists__; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(!empty($values['sub'])): ?>


                    <li class="treeview">
                        <a href="<?php echo e($values['url']); ?>"><i class="fa <?php echo e($values['icon']); ?>"></i> <span><?php echo e($values['name']); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php $__currentLoopData = $values['sub']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child_values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="li_diy_menu"><a href="<?php echo e($child_values['url']); ?>"><i class="fa fa-circle-o"></i><?php echo e($child_values['name']); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </li>

                <?php else: ?>

                    <li class="li_diy_menu"><a href="<?php echo e($values['url']); ?>"><i class="fa <?php echo e($values['icon']); ?>"></i> <span><?php echo e($values['name']); ?></span></a></li>

                <?php endif; ?>





            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <li class="header">标签</li>
            <li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>重要</span></a></li>
            <li><a href="#"><i class="fa fa-circle-o text-yellow"></i> <span>警告</span></a></li>
            <li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>消息</span></a></li>



        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>