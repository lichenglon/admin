
<?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<dl class="cate-item">
	<dt class="cf">
	<form action="" method="post">
		<div class="btn-toolbar opt-btn cf">
			
			
			<a class="layer-delete" href="<?php echo e(url('house/type/delete',['id'=>$values['id']])); ?>">删除</a>
		</div>
		<div class="fold"><i></i></div>
		<div class="order"><?php echo e($values['id']); ?></div>
		<div class="order"><input type="text" name="sort_number" class="text input-mini" value=""></div>
		<div class="order">
			<?php if(isset($cateStatus[$values['status']])): ?>
			<?php if($values['status'] == 0): ?>
			<a href="<?php echo e(url('category/menu/updateStatus')); ?>?status=<?php echo e($values['status']); ?>&id=<?php echo e($values['id']); ?>" status="" class="update_status" ><i style="color:#ccc;"><?php echo e($cateStatus[$values['status']]); ?></i></a>
			<?php else: ?>
			<a href="<?php echo e(url('category/menu/updateStatus')); ?>?status=<?php echo e($values['status']); ?>&id=<?php echo e($values['id']); ?>" class="update_status" ><?php echo e($cateStatus[$values['status']]); ?></a>
			<?php endif; ?>
			<?php endif; ?>
		</div>
		<div class="name">
			<span class="tab-sign"></span>
			<input type="hidden" name="id" value="<?php echo e($values['id']); ?>">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<input type="text" name="name" class="text" value="<?php echo e($values['name']); ?>">

			<a class="add-sub-cate" title="添加子分类" href="<?php echo e(url('category/menu/create',['pid'=>$values['id']])); ?> ">
				<i class="icon-add"></i>
			</a>
			<span class="help-inline msg"></span>
		</div>
	</form>
	</dt>
	<?php if(!empty($values['children'])): ?>
	<dd style="display:none;">
		<?php echo $__env->make('house.type.tree', ['tree' => $values['children']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</dd>
	<?php endif; ?>
</dl>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>